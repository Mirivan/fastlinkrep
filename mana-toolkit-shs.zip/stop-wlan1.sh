#!/bin/bash
ifconfig wlan1 down

