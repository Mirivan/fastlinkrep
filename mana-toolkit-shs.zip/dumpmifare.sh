#!/bin/bash
mfoc -O /root/mifare-dump-$(date +"%Y%m%d_%H%M%S").mfd
